<?php

class Sesbasic_Model_Notificationread extends Core_Model_Item_Abstract {

  protected $_searchTriggers = false;

}

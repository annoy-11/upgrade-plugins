DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesbasic_integrateothermodule';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesmusic_playlistsong';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesalbum_category';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesvideo_chanel';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesblog_review';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sespagebuilder_pagebuilder';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesadvancedcomment_gallery';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesvideo_category';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesvideo_slide';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesvideo_playlist';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesadvancedactivity_buysell';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesmultipleform_form';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesevent_host';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesevent_category';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'seseventreview_review';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesadvancedcomment_reaction';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesevent_ticket';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesevent_list';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesmember_review';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesmember_usercompliment';

DELETE FROM `engine4_core_search` WHERE `engine4_core_search`.`type` = 'sesmember_homepage';
<?php

/**
 * SocialEngineSolutions
 *
 * @category   Application_Sessportz
 * @package    Sessportz
 * @copyright  Copyright 2019-2020 SocialEngineSolutions
 * @license    http://www.socialenginesolutions.com/license/
 * @version    $Id: License.php  2019-04-16 00:00:00 SocialEngineSolutions $
 * @author     SocialEngineSolutions
 */

if (!$this->getRequest()->isPost()) {
  return;
}

if (!$form->isValid($this->getRequest()->getPost())) {
  return;
}

if ($this->getRequest()->isPost()) {


  //here we can set some variable for checking in plugin files.
  if (1) {

    if (!Engine_Api::_()->getApi('settings', 'core')->getSetting('sessportz.pluginactivated')) {
      $db = Zend_Db_Table_Abstract::getDefaultAdapter();

      $db->query('INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
			("sessportz_admin_main_menus", "sessportz", "Manage Header", "", \'{"route":"admin_default","module":"sessportz","controller":"manage", "action":"header-template"}\', "sessportz_admin_main", "", 3),
			("sessportz_admin_main_footer", "sessportz", "Footer", "", \'{"route":"admin_default","module":"sessportz","controller":"manage", "action":"footer-settings"}\', "sessportz_admin_main", "", 4),
			("sessportz_admin_main_styling", "sessportz", "Color Schemes", "", \'{"route":"admin_default","module":"sessportz","controller":"settings", "action":"styling"}\', "sessportz_admin_main", "", 5),

			("sessportz_admin_main_mansemail", "sessportz", "Newsletter Emails", "", \'{"route":"admin_default","module":"sessportz","controller":"manage-newsletter"}\', "sessportz_admin_main", "", 992),
            ("sessportz_admin_main_managenewsemails", "sessportz", "Emails", "", \'{"route":"admin_default","module":"sessportz","controller":"manage-newsletter"}\', "sessportz_admin_main_mansemail", "", 1),
            ("sessportz_admin_main_managesendnews", "sessportz", "Send Newsletter", "", \'{"route":"admin_default","module":"sessportz","controller":"manage-newsletter", "action":"send-newsletter"}\', "sessportz_admin_main_mansemail", "", 2);
      ');
      $db->query('DROP TABLE IF EXISTS `engine4_sessportz_teams`;');
      $db->query('CREATE TABLE IF NOT EXISTS `engine4_sessportz_teams` (
      `team_id` int(11) NOT NULL AUTO_INCREMENT,
      `name` varchar(255)  NOT NULL,
      `photo_id` int(11) NOT NULL,
      `position` int(11) NOT NULL,
      `wins` int(11) NOT NULL,
      `draw` int(11) NOT NULL,
      `loss` int(11) NOT NULL,
      `points` int(11) NOT NULL,
      `enabled` tinyint(1) NOT NULL DEFAULT "1",
      `order` int(11) DEFAULT NULL,
      PRIMARY KEY (`team_id`)
      ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;');
        $db->query("DROP TABLE IF EXISTS engine4_sessportz_newsletteremails;");
        $db->query('CREATE TABLE IF NOT EXISTS `engine4_sessportz_newsletteremails` (
            `newsletteremail_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `email` varchar(255) NOT NULL,
            `user_id` int(11) DEFAULT "0",
            `level_id` int(11) DEFAULT "5"
        ) ENGINE=InnoDB DEFAULT CHARSET=latin1;');
			$db->query('DROP TABLE IF EXISTS `engine4_sessportz_socialicons`;');
			$db->query('CREATE TABLE IF NOT EXISTS `engine4_sessportz_socialicons` (
				  `socialicon_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
				  `name` varchar(255) NOT NULL,
				  `title` varchar(255) NOT NULL,
				  `url` varchar(255) NOT NULL,
				  `enabled` tinyint(1) NOT NULL DEFAULT "1",
				  `order` int(11) NOT NULL,
				  PRIMARY KEY (`socialicon_id`)
			) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;');

		  $db->query('INSERT IGNORE INTO `engine4_sessportz_socialicons` (`socialicon_id`, `name`, `title`, `url`, `enabled`, `order`) VALUES
			(1, "facebook", "Like Us on Facebook", "http://facebook.com", 1, 1),
			(2, "google", "Google Plus", "http://google.com", 1, 2),
			(3, "linkdin", "Linkdin", "http://linkdin.com", 1, 3),
			(4, "twitter", "Twitter", "http://twitter.com", 1, 4),
			(5, "pinintrest", "Pinintrest", "http://pinintrest.com", 1, 5),
			(6, "instragram", "Instagram", "http://instagram.com", 1, 6),
			(7, "youtube", "YouTube", "http://youtube.com", 1, 7),
			(8, "vimeo", "Vimeo", "http://vimeo.com", 1, 8),
			(9, "tumblr", "Tumblr", "http://tumblr.com", 1, 9),
			(10, "flickr", "Flickr", "http://flickr.com", 1, 10)');

		  $db->query('DROP TABLE IF EXISTS `engine4_sessportz_footerlinks`;');
		  $db->query('CREATE TABLE IF NOT EXISTS `engine4_sessportz_footerlinks` (
			`footerlink_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
			`name` varchar(255) NOT NULL,
			`url` varchar(255) NOT NULL,
			`enabled` tinyint(1) NOT NULL DEFAULT "1",
			`sublink` tinyint(1) NOT NULL DEFAULT "0",
			PRIMARY KEY (`footerlink_id`)
			) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;');

		  $db->query('INSERT IGNORE INTO `engine4_sessportz_footerlinks` (`name`, `url`, `enabled`, `sublink`) VALUES
			("Footer Column 1", "", 1, 0),
			("Footer Column 2", "", 1, 0),
			("Footer Column 3", "", 1, 0);');

		  $db->query('DROP TABLE IF EXISTS `engine4_sessportz_managesearchoptions`;');
		  $db->query('CREATE TABLE IF NOT EXISTS `engine4_sessportz_managesearchoptions` (
			  `managesearchoption_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
			  `type` varchar(255) NOT NULL,
			  `title` varchar(255) NOT NULL,
			  `file_id` INT(11) DEFAULT "0",
			  `enabled` tinyint(1) NOT NULL DEFAULT "1",
			  `order` int(11) NOT NULL,
			  PRIMARY KEY (`managesearchoption_id`)
			) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;');

      include_once APPLICATION_PATH . "/application/modules/Sessportz/controllers/defaultsettings.php";
      Engine_Api::_()->getApi('settings', 'core')->setSetting('sessportz.pluginactivated', 1);
    }
  }
}

<?php

/**
 * SocialEngineSolutions
 *
 * @category   Application_Sessportz
 * @package    Sessportz
 * @copyright  Copyright 2019-2020 SocialEngineSolutions
 * @license    http://www.socialenginesolutions.com/license/
 * @version    $Id: Checklicense.php  2019-04-16 00:00:00 SocialEngineSolutions $
 * @author     SocialEngineSolutions
 */
	Zend_Registry::set('sessportz_adminmenu', 1);
	Zend_Registry::set('sessportz_header', 1);
	Zend_Registry::set('sessportz_footer', 1);
	Zend_Registry::set('sessportz_widget', 1);
